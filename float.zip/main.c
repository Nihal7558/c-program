#include <stdio.h>
int main()
{
float b;
printf("enter the number");
scanf("%f",&b);
printf("cube of number is. %f",b*b*b);
return 0;
    
    
    
    
    
    
}