#include <stdio.h>
int main(){
int a;
printf("enter a number");
scanf("%d",&a);
printf("cube of number is.%d",a*a*a);
return 0;
}